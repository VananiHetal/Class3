public class Circle {
    //inside the class -inside the method
//pie value is 3.14 radius = 8 is radius of circle
    // Java main method :This mathod will calculate area of circle

    public static void main(String []args ){
      int radius = 8;
      double area = Math.PI *radius*radius;

        System.out.println("Area of a circle =" + area);
    }



}
