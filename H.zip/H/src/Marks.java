public class Marks {
    //inside the class in side the method
    //subject mark: maths = 50 science =60 english =70 out of 100
    //Average = total/totalsubjects
    //percentage =( total/(totalsubjects *100))*
public static void main(String []args ) {

    int maths = 50;
    int science = 60;
    int english = 70;
    int total=(maths+science+english);
    int percentage= (total/3);
System.out.println(total);
System.out.println(percentage);
}





}
