public class Triangle {
    //inside the class in side the method key world.
    //a=5, b=7 where a and b are the side of triangle
    //c=hypotenuse value
    public static void main(String[]args){

        double a =5, b = 7 ;
        double c = (a*a)+(b*b);
              c =  Math.sqrt('c');
        System.out.println(c);

    }
}
